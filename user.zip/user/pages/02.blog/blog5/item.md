---
title: 'Selamat Hari Batik Nasional'
date: '13:34 05/24/2024'
author: 'Rescue Themes'
body_classes: 'single single-post postid-15 single-format-standard group-blog'
taxonomy:
    category: Event
    tag:
        - Event
        - 'National Event'
---

[HIMAKI BERBATIK]

Selamat Hari Batik!

Mari kita sambut bulan Oktober dengan merayakan keindahan budaya batik.

Hari ini, sobat Himaki tampil estetik mengenakan batik dalam berbagai corak dan warna, loh! 🤩

Siapa yang hari ini berbatik juga? Yuk, bersama-sama menjaga warisan batik kita.

