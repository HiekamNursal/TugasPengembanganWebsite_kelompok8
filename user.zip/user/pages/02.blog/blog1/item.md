---
title: 'INTERNATIONAL COMMUNITY DEVELOPMENT 2023'
date: '08:11 04/20/2024'
author: 'Rescue Themes'
body_classes: 'single single-post postid-15 single-format-standard group-blog'
taxonomy:
    category:
        - Training
    tag:
        - 'International Community Development'
        - ICD
    featured:
        - '1'
---

[INTERNATIONAL COMMUNITY DEVELOPMENT 2023]

Excellent chemistry !!
Bravo Himaki!!

Pada 9-15 Agustus 2023, Departemen Kimia telah melaksanakan sebuah kegiatan pengabdian masyarakat yang melibatkan kolaborasi antara mahasiswa program studi Kimia Universitas Airlangga dengan mahasiswa internasional.