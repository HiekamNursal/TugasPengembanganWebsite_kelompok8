---
title: 'Mars HIMAKI'
---

##### MARS HIMAKI

Arti:
Keberadaan Mars HIMAKI dimaknai sebagai pemberi semangat bagi seluruh warga HIMAKI, juga sebagai salah satu bentuk cinta dan rasa memiliki atas HIMAKI. Maka dalam aplikasinya, Mars ini selalu dijadikan pembuka serta penutup setiap kegiatan HIMAKI, baik rapat pengurus, program kerja, ataupun agenda-agenda yang sedang dilaksanakan.

Kilas Sejarah:
Penciptaan Mars oleh tiga mahasiswa Kimia angkatan 2004, yaitu Agus Yulianto, Bayu Ratra, dan Rangga, merupakan salah satu bentuk tugas dalam masa OSPEK di tahun 2004. Namun, kemudian Mars ini diresmikan dalam Musyawarah Besar pada tahun 2005 untuk dilegalkan dan dijadikan bagian dari alat kelengkapan HIMAKI. Walaupun diciptakan oleh tiga mahasiswa Kimia, namun Mars HIMAKI pada masa itu diresmikan atas nama Mahasiswa Kimia Angkatan 2004.